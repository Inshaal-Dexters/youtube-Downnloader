from pytube import YouTube

e_url = str(input("Enter a Link"))
yt = YouTube(url=e_url)
video = yt.streams.get_highest_resolution()
video.download()
